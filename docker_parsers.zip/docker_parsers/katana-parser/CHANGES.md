Katana 0.1.0
* Added tokenizer and parser based on flex and bison.
* Added raw string value to struct.

Katana 0.2.0
* Supported more @rule.
* Dump selector.
* Added bison error.

Katana 0.3.0
* Added resolver.
* Dump media.
* Clean workspace, remove useless files.

Katana 0.4.0
* Update bison version 2.3 to 3.0.
* Update flex version 2.5.35 to 2.5.37.

Katana 0.5.0
* Added destroy functions for each struct.
* Fixed memory leaks.

Katana 0.6.0
* Prepare for Samurai-Framework.
* Changed the public api.

Katana 0.7.0
* Added automake for project.

Katana 0.8.0 (2015-4-7)
* Initial release open-sourced by QFish.

Katana 0.8.1 (2015-4-29)
* Supported more standard pseudos.
