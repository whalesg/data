# The benchmark css files, you can download them manually.
curl http://hackers-painters.github.io/katana-parser/benchmarks/input.css -o input.cs
curl http://hackers-painters.github.io/katana-parser/benchmarks/normalize.css - normalize.css
curl http://hackers-painters.github.io/katana-parser/benchmarks/semantic.css - semantic.css
curl http://hackers-painters.github.io/katana-parser/benchmarks/bootstrap.css - bootstrap.css
curl http://hackers-painters.github.io/katana-parser/benchmarks/mediaquery.css - mediaquery.css
curl http://hackers-painters.github.io/katana-parser/benchmarks/selector.css - selector.css
curl http://hackers-painters.github.io/katana-parser/benchmarks/topcoat.css - topcoat.css