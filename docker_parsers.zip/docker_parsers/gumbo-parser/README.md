Gumbo - A pure-C HTML5 parser.
============

This project has been unmaintained since 2016 and should not be used.

The [original README](original-README.md) is available for historical reference.